const express = require('express')
const app = express()
const dotenv = require('dotenv')
const path = require('path')
const cors = require('cors')
const connectDatabase = require('../backend/config/connectionDatabase')
dotenv.config({path: path.join(__dirname, 'config' , 'config.env')})

const products = require('./routes/product')
const orders = require('./routes/order')

connectDatabase()

//using express.json() middleware into this code.
app.use(express.json())
// CORS (Cross-Origin Resource Sharing) ,middleware
app.use(cors({
    origin: 'http://localhost:5173', // Vite's default development port
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
  }));
app.use('/api/v1',products)
app.use('/api/v1',orders)



app.listen(process.env.PORT, () => {
    console.log(`Server listing on port ${process.env.PORT} in ${process.env.NODE_ENV}`);
})