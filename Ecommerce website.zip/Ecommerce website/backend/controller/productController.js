const productModel = require('../models/productModel')

// To get all products in that api call : /api/v1/products
exports.getProducts = async (req, res, next) => {

    // this is kinda filter the particular product
   const query = req.query.keyword?{name : {  ///name is avalible in given API
                                        $regex: req.query.keyword,
                                        $options: 'i',  //this helps for case sensitive 
                                    }}:{}
    
    const products = await productModel.find(query)

    res.json({
        success: true,
        products
    })

    
}

// To get the particular product : /api/v1/product/:id
exports.getSingleProducts = async (req, res, next) => {
    
    try {
        const product = await productModel.findById(req.params.id)
        res.json({
            success : true,
            product
        })
        
    } catch (error) {
        res.status(404).json({
            success : false,
            errorrror : "unable to find the API"
        })
    }
   
}