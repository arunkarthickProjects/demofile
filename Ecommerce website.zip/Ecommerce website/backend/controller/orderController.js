// req handler
const orderModel = require('../models/orderModule')
const productModel = require('../models/productModel')

exports.createOrder = async (req, res, next) => {

    const cartItems = req.body;
    const amount = cartItems.reduce((acc ,items) => Number(acc + items.product.price * items.qty),0).toFixed(2)
    const status = "pending"

   const orderProduct = new orderModel({cartItems,amount,status, createAt: new Date()})

   // Save the order to the database // Important step to follow to save the data to the database
   await orderProduct.save();

   cartItems.forEach( async(item) => {
    const product =await productModel.findById(item.product._id)
    product.stock = product.stock - item.qty
    await product.save()
   })

    


    res.json({
        success : true,
        orderProduct
    })
}