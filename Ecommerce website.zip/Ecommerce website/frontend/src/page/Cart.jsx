import React, { useState } from 'react'
import {Link} from 'react-router-dom'
import { toast } from "react-toastify";

const Cart = ({cartItems,setCartItems}) => {

    const [complete, setComplete] = useState(false)



    const HandlePlus = (Item) => {
        if(Item.product.stock == Item.qty){
            return;
        }
        const updatedItems = cartItems.map((i) => {
            if(i.product._id == Item.product._id){
                i.qty++
            }
            return i
        }) 
        setCartItems(updatedItems)       
    }

    const Handleminus = (Item) => {
        if(Item.qty<=1){
            return;
        }
        const updatedItems= cartItems.map((i) => {
            if(i.product._id == Item.product._id){
                i.qty--
            }
            return i;
        }) 
        setCartItems(updatedItems)       
    }

    const deleteItem = (i) => {
        const updatedItems= cartItems.filter((val) => val.product._id !== i.product._id )
        setCartItems(updatedItems)
    }

    const orderPlaced = async () => {
        const APIURL = import.meta.env.VITE_API_URL;
      
        try {
          const response = await fetch(`${APIURL}/order`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(cartItems),
          });
      
          if (!response.ok) {
            throw new Error('Failed to place the order');
          }
      
          // Clear cart and set order completion state
          setCartItems([]);
          setComplete(true);
      
          return await response.json(); // Return the response data if needed
        } catch (error) {
          console.error('Error placing order:', error);
          // Optionally handle error (e.g., show error message to the user)
        }
      };

  return (
    cartItems.length >0 ?
    <>
        <div className="container container-fluid">
                <h2 className="mt-5">Your Cart: <b>{cartItems.length} items</b></h2>
                
                    <div className="row d-flex justify-content-between">
                        <div className="col-12 col-lg-8">

                            {cartItems.map((Item) => 
                                ( <>
                                    <hr />
                                      <div className="cart-item"  >
                                                <div className="row">
                                                    <div className="col-4 col-lg-3">
                                                        <img src={Item.product.images[0].image} alt={Item.product.name} height="90" width="115" />
                                                    </div>
    
                                                    <div className="col-5 col-lg-3">
                                                        <Link to={"/product/"+Item.product._id}>{Item.product.name}</Link>
                                                    </div>
    
    
                                                    <div className="col-4 col-lg-2 mt-4 mt-lg-0">
                                                        <p id="card_item_price">${Item.product.price}</p>
                                                    </div>
    
                                                    <div className="col-4 col-lg-3 mt-4 mt-lg-0">
                                                        <div className="stockCounter d-inline">
                                                            <span className="btn btn-danger minus" onClick={() => Handleminus(Item)}>-</span>
                                                            <input type="number" className="form-control count d-inline" value={Item.qty} readOnly />
    
                                                            <span className="btn btn-primary plus" onClick={() => HandlePlus(Item)}>+</span>
                                                        </div>
                                                    </div>
    
                                                    <div className="col-4 col-lg-1 mt-4 mt-lg-0">
                                                        <i id="delete_cart_item" className="fa fa-trash btn btn-danger" onClick={() => deleteItem(Item)}></i>
                                                    </div>
    
                                                </div>
                                      </div>
                                </>
                                )
                            
                            )}
                            
                            
                        
                        </div>

                        <div className="col-12 col-lg-3 my-4">
                            <div id="order_summary">
                                <h4>Order Summary</h4>
                                <hr />
                                <p>Subtotal:  <span className="order-summary-values">{cartItems.reduce((acc,val) => (val.qty) + acc,0)}</span></p>
                                <p>Est. total: <span className="order-summary-values">${cartItems.reduce((acc,val) => ((val.product.price * val.qty) + acc),0)}</span></p>

                                <hr />
                                <button id="checkout_btn" className="btn btn-primary btn-block" onClick={orderPlaced}>Place Order</button>
                            </div>
                        </div>
                    </div>
        </div>
    </> :
        <div className="d-flex justify-content-center align-items-center vh-100">
        {!complete ? (
            <h2 className="mt-5">Your Cart is Empty!</h2>
        ) : (
            <div className="text-center">
            <h2>Your Order is Successfully Placed!</h2>
            {toast.success('Order successfully placed!')}
            </div>
        )}
        </div>
        
  )
}

export default Cart