import React from 'react'
import ProductCard from '../component/ProductCart.jsx'
import { useState } from 'react'
import { useEffect } from 'react'
import { useSearchParams } from 'react-router'





const Home = () => {

  const[Products,setProducts] = useState([])
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const apiUrl = import.meta.env.VITE_API_URL; 
    const searchKeyword = searchParams.get("keyword") || ""; // Extract 'keyword' param

    console.log("Current search params:", searchParams.toString());
    console.log("Search keyword:", searchParams.get("keyword")); // ensure that what we giving key value in backEnd check productController "req.query.keyword"

     console.log(apiUrl);
    // fetch(`${apiUrl}/product`).then(res => res.json()).then(res => setProducts(res.products))
   
  const fetchProducts = async() => {
       try {
        const queryString = `keyword=${encodeURIComponent(searchKeyword)}`;
        const response = await fetch(`${apiUrl}/product?${queryString}`);
         console.log('Fetching from URL:', `${apiUrl}/product`); 
        if(!response.ok){
         throw new Error ('Network response was not okay')
        }
        const data =await response.json()
        console.log('Data:', data);
        setProducts(data.products)
        
       } catch (error) {
        console.log('Error fetching products:', error);
       }
    };

    fetchProducts();

  },[searchParams])

  return (
    <>
      <h1 id="products_heading">Latest Products</h1>
      <section id="products" className="container mt-5">
        <div className="row">
          
          {Products.map((product) => <ProductCard  product={product}/>)}
         
        </div>
      </section>
    </>
  )
}

export default Home