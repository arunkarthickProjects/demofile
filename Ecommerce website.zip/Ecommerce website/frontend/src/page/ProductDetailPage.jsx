import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router'
import { toast } from "react-toastify";

const ProductDetailPage = ({cartItems,setCartItems}) => {
    
    const [product, setProduct]=useState(null)
    const [qty,setQty]=useState(1)

    const {id}=useParams() // get the id from URL 

    useEffect(() => {
       const APIURL = import.meta.env.VITE_API_URL
       
       const fetchProducts = async () => {
        try {
            const response =await fetch(`${APIURL}/product/${id}`)
            if(!response.ok){
                throw new Error ('Network response was not okay')
            }
            const data =await response.json()
            setProduct(data.product)
        } catch (error) {
            console.log('Error fetching products:', error);
        }
       }
       
       if(id){

           fetchProducts()
       }
       
    },[])

    const addToCart = () => {
        let cartExisted = cartItems.find((val) => val.product._id === product._id)
        if(!cartExisted){
            let newItem = {product,qty}
            setCartItems((prev) => [...prev,newItem])
            toast.success('New Item is added to cart successfully')
        }    
    }

    const HandlePlus = () => {
        if(product.stock == qty){
            return;
        }
        setQty((state) => state + 1)        
    }

    const Handleminus = () => {
        if(qty<=1){
            return;
        }
        setQty((state) => state - 1)        
    }


  return (
    product && <div className="container container-fluid">
                    <div className="row f-flex justify-content-around">
                        <div className="col-12 col-lg-5 img-fluid" id="product_image">
                            <img src={product.images[0].image} alt="sdf" height="500" width="500" />
                        </div>

                        <div className="col-12 col-lg-5 mt-5">
                            <h3>{product.name}</h3>
                            <p id="product_id">{product._id}</p>

                            <hr/>

                            <div className="ratings mt-auto">
                                <div className="rating-outer">
                                <div className="rating-inner" style={{width : `${product.ratings/5 * 100}%`}} ></div>
                                </div>
                            </div>
                    

                            <hr/>

                            <p id="product_price">${product.price}</p>
                            <div className="stockCounter d-inline">
                                <span className="btn btn-danger minus" onClick={Handleminus}>-</span>

                                <input type="number" className="form-control count d-inline" value={qty} readOnly />

                                <span className="btn btn-primary plus" onClick={HandlePlus}>+</span>
                            </div>
                            <button type="button" id="cart_btn" className="btn btn-primary d-inline ml-4" onClick={addToCart} disabled={product.stock == 0} >Add to Cart</button>

                            <hr/>
                            
                            <p>Status: <span id="stock_status" className={product.stock >0 ? 'text-success':'text-danger'}>{product.stock >0 ? 'In Stock' : 'out of stock'}</span></p> 

                            

                            <hr/>

                            <h4 className="mt-2">Description:</h4>
                            <p>{product.description}</p>
                            <hr/>
                            <p id="product_seller mb-3">Sold by: <strong>{product.seller}</strong></p>
                            
                            <div className="rating w-50"></div>
                                    
                        </div>

                    </div>
                </div>
  )
}

export default ProductDetailPage