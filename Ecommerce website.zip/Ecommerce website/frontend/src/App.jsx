import './App.css'
import Footer from './component/Footer.jsx'
import Header from './component/Header.jsx'
import Home from './page/Home.jsx'
import {BrowserRouter, Routes, Route} from 'react-router'
import ProductDetailPage from './page/ProductDetailPage.jsx'
import { useState } from 'react'
import {ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Cart from './page/Cart.jsx'

function App() {
     const[cartItems,setCartItems]=useState([])

  return (
        <>
      <BrowserRouter>
      <div>
      <ToastContainer theme='dark' position='top-center' />
      <Header cartItems={cartItems}/>
          <Routes>
            <Route path='/' element={<Home />}></Route>
            <Route path='/Search' element={<Home/>}></Route>
            <Route path='/product/:id' element={<ProductDetailPage cartItems={cartItems} setCartItems={setCartItems}/>}></Route>
            <Route path='/Cart' element={<Cart cartItems={cartItems} setCartItems={setCartItems}/>}></Route>
          </Routes>
      </div>
          
          <Footer/>
      </BrowserRouter>
    </>
      
  
  )
}

export default App
