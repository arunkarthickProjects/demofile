import React, { useState } from 'react'
import {useNavigate} from 'react-router-dom'

const Search = () => {
    const navigate = useNavigate()

    const [userSearch,setuserSearch] = useState("")

    const handleChange = (e) => {
        // const {name,value} = e.target

        // setuserSearch(prev => {
        //     return {
        //         ...prev,
        //         [name]:value,
        //     }
        // })
        setuserSearch(e.target.value)
    }

 const handleSearch = () => {
    navigate('/search?keyword='+userSearch)
 }

  return (
    <div className="input-group">
          <input
            name='userInput'
            type="text"
            id="search_field"
            className="form-control"
            onBlur={handleSearch}
            placeholder="Enter Product Name ..."
            onChange={handleChange}
          />
          <div className="input-group-append">
            <button id="search_btn" className="btn" onClick={handleSearch}>
              <i className="fa fa-search" aria-hidden="true"></i>
            </button>
          </div>
        </div>
  )
}

export default Search